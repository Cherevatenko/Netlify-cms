declare module 'redux-notifications';
