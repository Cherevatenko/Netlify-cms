import { NetlifyCmsCore as CMS } from 'netlify-cms-core';
import { en } from 'netlify-cms-locales';

CMS.registerLocale('en', en);
