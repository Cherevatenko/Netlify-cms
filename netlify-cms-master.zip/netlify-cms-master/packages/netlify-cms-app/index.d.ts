declare module 'netlify-cms-app' {
  import type { CMS } from 'netlify-cms-core';

  export const NetlifyCmsApp: CMS;

  export default NetlifyCmsApp;
}
